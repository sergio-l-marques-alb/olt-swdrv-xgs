/* $Id: vlan.h,v 1.32 Broadcom SDK $
* $Copyright: Copyright 2012 Broadcom Corporation.
* This program is the proprietary software of Broadcom Corporation
* and/or its licensors, and may only be used, duplicated, modified
* or distributed pursuant to the terms and conditions of a separate,
* written license agreement executed between you and Broadcom
* (an "Authorized License").  Except as set forth in an Authorized
* License, Broadcom grants no license (express or implied), right
* to use, or waiver of any kind with respect to the Software, and
* Broadcom expressly reserves all rights in and to the Software
* and all intellectual property rights therein.  IF YOU HAVE
* NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE
* IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
* ALL USE OF THE SOFTWARE.  
*  
* Except as expressly set forth in the Authorized License,
*  
* 1.     This program, including its structure, sequence and organization,
* constitutes the valuable trade secrets of Broadcom, and you shall use
* all reasonable efforts to protect the confidentiality thereof,
* and to use this information only in connection with your use of
* Broadcom integrated circuit products.
*  
* 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS
* PROVIDED "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
* REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY,
* OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
* DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
* NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
* ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
* CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
* OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
* 
* 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
* BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL,
* INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER
* ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY
* TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF
* THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR USD 1.00,
* WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
* ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.$
* $Copyright: Copyright 2012 Broadcom Corporation.
* This program is the proprietary software of Broadcom Corporation
* and/or its licensors, and may only be used, duplicated, modified
* or distributed pursuant to the terms and conditions of a separate,
* written license agreement executed between you and Broadcom
* (an "Authorized License").  Except as set forth in an Authorized
* License, Broadcom grants no license (express or implied), right
* to use, or waiver of any kind with respect to the Software, and
* Broadcom expressly reserves all rights in and to the Software
* and all intellectual property rights therein.  IF YOU HAVE
* NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE
* IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
* ALL USE OF THE SOFTWARE.  
*  
* Except as expressly set forth in the Authorized License,
*  
* 1.     This program, including its structure, sequence and organization,
* constitutes the valuable trade secrets of Broadcom, and you shall use
* all reasonable efforts to protect the confidentiality thereof,
* and to use this information only in connection with your use of
* Broadcom integrated circuit products.
*  
* 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS
* PROVIDED "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
* REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY,
* OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
* DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
* NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
* ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
* CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
* OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
* 
* 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
* BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL,
* INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER
* ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY
* TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF
* THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR USD 1.00,
* WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
* ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.$
 * $
*/

#ifndef _BCM_INT_DPP_VLAN_H
#define _BCM_INT_DPP_VLAN_H

#include <sal/types.h>
#include <bcm/types.h>
#include <bcm/vlan.h>
#include <soc/types.h>
#include <soc/dpp/SAND/Utils/sand_multi_set.h>
#include <soc/dpp/PPD/ppd_api_lif.h>
#include <soc/dpp/PPD/ppd_api_lif_ing_vlan_edit.h>
#include <soc/dpp/PPD/ppd_api_eg_vlan_edit.h>
#include <soc/dpp/PPD/ppd_api_llp_parse.h>
#include <soc/dpp/dpp_wb_engine.h>
/*
 * Define:
 *    VLAN_CHK_ID
 * Purpose:
 *    Causes a routine to return BCM_E_BADID if the specified
 *    VLAN ID is out of range.
 */

#define BCM_DPP_VLAN_CHK_ID(unit, vid) do { \
    if (vid > BCM_VLAN_MAX) BCMDNX_ERR_EXIT_MSG(BCM_E_PARAM, (_BSL_BCM_MSG("Invalid VID"))); \
    } while (0);

/*
 * Define:
 *    ING_TUNNEL_CHK_ID
 * Purpose:
 *    Causes a routine to return BCM_E_BADID if the specified
 *    TUNNEL ID is out of range.
 */

#define BCM_DPP_ING_TUNNEL_CHK_ID(unit, tunnel) do { \
    if (tunnel > 2047) BCMDNX_ERR_EXIT_MSG(BCM_E_PARAM, (_BSL_BCM_MSG("Invalid ingress Tunnel ID"))); \
    } while (0);

/*
 * Define:
 *    EGR_TUNNEL_CHK_ID
 * Purpose:
 *    Causes a routine to return BCM_E_BADID if the specified
 *    TUNNEL ID is out of range.
 */

#define BCM_DPP_EGR_TUNNEL_CHK_ID(unit, tunnel) do { \
    if (tunnel > 4096) BCMDNX_ERR_EXIT_MSG(BCM_E_PARAM, (_BSL_BCM_MSG("Invalid egress Tunnel ID"))); \
    } while (0);

/*
 * Define:
 *    VLAN_PORT_CLASS_VALID
 * Purpose:
 *    Causes a routine to return BCM_E_PARAM if the specified
 *    PORT CLASS is out of range.
 */

#define BCM_DPP_PORT_CLASS_VALID(port_class) do { \
    if (port_class > 255) BCMDNX_ERR_EXIT_MSG(BCM_E_PORT, (_BSL_BCM_MSG("Invalid port class"))); \
    } while (0);

/*
 * Define:
 *    VLAN_CHK_PRIO
 * Purpose:
 *    Causes a routine to return BCM_E_PARAM if the specified
 *    priority (802.1p CoS) is out of range.
 */

#define BCM_DPP_VLAN_CHK_PRIO(unit, prio) do { \
    if ((prio < BCM_PRIO_MIN || prio > BCM_PRIO_MAX)) BCMDNX_ERR_EXIT_MSG(BCM_E_PARAM, (_BSL_BCM_MSG("Invalid priority"))); \
    } while (0);

#define BCM_DPP_VLAN_CHK_ACTION(unit, action) do { \
    if (action < bcmVlanActionNone || action > bcmVlanActionCopy) BCMDNX_ERR_EXIT_MSG(BCM_E_PARAM, (_BSL_BCM_MSG("Invalid action"))); \
    } while (0);


/* 
  * In case of vlan port match is BCM_VLAN_PORT_MATCH_PORT, 
  * if vsi is set to -1, the VSI  assignment is set to SOC_PPC_VSI_EQ_IN_VID.
  */
#define _BCM_DPP_VSI_USE_AS_ASSIGNMENT_MODE(_vsi) (_vsi == BCM_VLAN_ALL)


/* Default forward profile for VSIs. Part of mapping to vsi default default forward
 * info. See soc_ppd_vsi_default_frwrd_info_set.
 * default forward profile 0 maps unknown UC/MC/BC to mc group 0 + vsid
 * default forward profile 1 maps unknown UC to mc group 0 + vsid, unknown MC to 4K + vsid,
 * and unkonwn BC to 8K + vsid.
 */

#define DPP_VSI_DEFAULT_DROP_PROFILE (0)
#define DPP_VSI_DEFAULT_FRWRD_PROFILE (3)
#define DPP_VSI_DEFAULT_FRWRD_PROFILE_UC_0_MC_4K_UC_8K (2)
#define DPP_BVID_DEFAULT_FRWRD_PROFILE (1) /* for mac in mac, point to trap flooding, base = 12K*/

#define DPP_NOF_SHARED_FIDS (7)

/* unknown-da trap-actions for drop/flooding */
#define _BCM_DPP_VLAN_UNKNOWN_DA_DROP_TRAP  (SOC_PPD_TRAP_CODE_UNKNOWN_DA_0)
#define _BCM_DPP_VLAN_UNKNOWN_DA_FLD_TRAP  (SOC_PPD_TRAP_CODE_UNKNOWN_DA_1)
#define _BCM_DPP_BVID_UNKNOWN_DA_FLD_TRAP  (SOC_PPD_TRAP_CODE_UNKNOWN_DA_7)

#define DPP_PRTCL_NOF_ETHER_TYPE_IDS (16)
#define NOS_PRTCL_PORT_PROFILES (8)


#define BCM_DPP_NOF_BRIDGE_VLANS (BCM_VLAN_INVALID)

/* Advanced VLAN edit mode defines */
#define   DPP_NOF_INGRESS_VLAN_EDIT_PROFILES        (8)

#define   DPP_NOF_EGRESS_VLAN_EDIT_PROFILE_BITS(unit)   (SOC_DPP_DEFS_GET(unit, nof_eve_profile_bits))
#define   DPP_NOF_EGRESS_VLAN_EDIT_PROFILES(unit)       (0x1 << (DPP_NOF_EGRESS_VLAN_EDIT_PROFILE_BITS(unit)))
#define   DPP_EGRESS_VLAN_EDIT_PROFILE_MASK(unit)       (DPP_NOF_EGRESS_VLAN_EDIT_PROFILES(unit) - 1)

#define   DPP_NOF_VLAN_TAG_FORMATS                  (16)
#define   DPP_VLAN_TAG_FORMAT_MASK                  (0xF)

/*
 * Define:
 *    BCM_DPP_VLAN_EDIT_PROFILE_VALID
 * Purpose:
 *    Causes a routine to return BCM_E_PARAM if the specified
 *    VLAN edit profile is out of range.
 */

#define BCM_DPP_VLAN_EDIT_PROFILE_VALID(unit, vlan_edit_profile, is_ingress) do {                               \
    if ( (is_ingress && (vlan_edit_profile >= DPP_NOF_INGRESS_VLAN_EDIT_PROFILES)) ||                           \
        (!is_ingress && (vlan_edit_profile >= DPP_NOF_EGRESS_VLAN_EDIT_PROFILES(unit))))                              \
            BCMDNX_ERR_EXIT_MSG(BCM_E_PARAM, (_BSL_BCM_MSG("Invalid VLAN edit profile")));                             \
    } while (0)


/*
 * The entire vlan_info structure is protected by BCM_LOCK.
 */
typedef struct bcm_dpp_vlan_info_s {
    int        init;      /* TRUE if VLAN module has been inited */
    bcm_vlan_t defl;      /* Default VLAN */
    bcm_pbmp_t defl_pbmp; /* Memeber ports of default vlan */
    bcm_pbmp_t defl_ubmp; /* Untagged ports of default vlan */
    SHR_BITDCL vlan_bmp[_SHR_BITDCLSIZE(BCM_VLAN_COUNT)]; /* Existing VLANs */
    int        count;     /* Number of existing VLANs */
} bcm_dpp_vlan_info_t;

/* struct used to maintain reference count to used FIDs */
typedef struct {
    int ref_count;
    int fid;
} fid_ref_count_t;

/*
 *  Working state description (per unit)
 */
#ifdef BCM_WARM_BOOT_SUPPORT
typedef struct _bcm_dpp_vlan_wb_state_s {
    /* backing store state -- assigned */
    soc_scache_handle_t handle;                 /* backing store handle */
    uint8 *buffer;                              /* backing store buffer */
    unsigned int totalSize;                     /* backing store size */
    /* backing store state -- stated */
    uint16 version;                             /* backing store version */
    uint16 padding;                             /* algin the rest */
    unsigned int vlanCount;                     /* VLANs supported */
    unsigned int sharedFids;                    /* shared FIDs supported */
    unsigned int portsInPbmp;                   /* ports in a PBMP */
    /* backing store state -- computed */
    unsigned int offsetVlanInfo;                /* vlan_info offset */
    unsigned int offsetFidRefs;                 /* FID ref count offset */
} _bcm_dpp_vlan_wb_state_t;
#endif /* def BCM_WARM_BOOT_SUPPORT */
typedef struct _bcm_dpp_vlan_unit_state_s {
    bcm_dpp_vlan_info_t vlan_info;
    fid_ref_count_t fid_ref_count[DPP_NOF_SHARED_FIDS];
#ifdef BCM_WARM_BOOT_SUPPORT
    _bcm_dpp_vlan_wb_state_t wb;
#endif /* def BCM_WARM_BOOT_SUPPORT */
} _bcm_dpp_vlan_unit_state_t;

extern _bcm_dpp_vlan_unit_state_t *_bcm_dpp_vlan_unit_state[BCM_UNITS_MAX];

uint32
  _sand_multiset_buffer_get_entry(
    SOC_SAND_IN  int                             unit,
    SOC_SAND_IN  uint32                             sec_hanlde,
    SOC_SAND_IN  uint8                              *buffer,
    SOC_SAND_IN  uint32                             offset,
    SOC_SAND_IN  uint32                             len,
    SOC_SAND_OUT uint8                              *data
  );

uint32
  _sand_multiset_buffer_set_entry(
    SOC_SAND_IN  int                             unit,
    SOC_SAND_IN  uint32                             sec_hanlde,
    SOC_SAND_INOUT  uint8                           *buffer,
    SOC_SAND_IN  uint32                             offset,
    SOC_SAND_IN  uint32                             len,
    SOC_SAND_IN  uint8                              *data
  );

/*
 * set STP state for port and topology
 */
int
_bcm_ppd_stg_stp_port_set(int unit, bcm_stg_t stg_id, bcm_port_t port, int stp_state);

int
_bcm_ppd_stg_stp_port_get(int unit, bcm_stg_t stg_id, bcm_port_t port, int *stp_state);

int
_bcm_petra_vlan_flooding_per_lif_set(int unit, bcm_port_t port, SOC_PPD_LIF_ID lif_index, int is_port_flooding,  
                                     int is_lif_flooding, bcm_gport_t unknown_unicast_group, 
                                     bcm_gport_t unknown_multicast_group, bcm_gport_t broadcast_group);

int
_bcm_petra_vlan_flooding_per_lif_get(int unit, bcm_port_t port, SOC_PPD_LIF_ID lif_index, int is_port_flooding,
                                     int is_lif_flooding, bcm_gport_t *unknown_unicast_group, 
                                     bcm_gport_t *unknown_multicast_group, bcm_gport_t *broadcast_group);

int 
_bcm_petra_vlan_stg_set(int unit, bcm_vlan_t vid, bcm_stg_t stg);

typedef struct bcm_dpp_vlan_egress_priority_mapping_s {
    /* Priority (PCP & DEI) */
        SOC_SAND_PP_PCP_UP pcp; 
        SOC_SAND_PP_DEI_CFI dei; 
} bcm_dpp_vlan_egress_priority_mapping_t;

typedef struct bcm_dpp_vlan_egress_priority_mapping_table_info_s {
    /* Priority (PCP & DEI) per TC * DP */
    bcm_dpp_vlan_egress_priority_mapping_t    pcp_dei[SOC_SAND_PP_TC_MAX + 1][SOC_SAND_PP_DP_MAX + 1];
} bcm_dpp_vlan_egress_priority_mapping_table_info_t;

typedef struct bcm_dpp_vlan_edit_profile_mapping_info_s {
        /* 
         *  Edit Profile defined by the mapping:
         *  Per VLAN Structure, which IVEC attributes
         */
    SOC_PPD_LIF_ING_VLAN_EDIT_COMMAND_INFO ivec[SOC_SAND_PP_NOF_ETHERNET_FRAME_VLAN_FORMATS];
} bcm_dpp_vlan_edit_profile_mapping_info_t;

typedef struct bcm_dpp_vlan_egress_edit_profile_info_s {
        /* 
         *  Egress Edit Profile 
         *  Per VLAN Structure, which EVEC attributes
         */
    SOC_PPD_EG_VLAN_EDIT_COMMAND_INFO evec[SOC_SAND_PP_NOF_ETHERNET_FRAME_VLAN_FORMATS];
} bcm_dpp_vlan_egress_edit_profile_info_t;

typedef struct bcm_dpp_vlan_flooding_profile_info_s {

  /* 
   *  Unknown Unicast addition in case of flooding
   */
  int unknown_uc_add;
  /* 
   *  Unknown Multicast addition in case of flooding
   */
  int unknown_mc_add;
  /* 
   *  Unknown BC addition in case of flooding
   */
  int bc_add;
} bcm_dpp_vlan_flooding_profile_info_t;

typedef struct bcm_dpp_vlan_port_protocol_profile_info_s {
  /* 
   *  Ethertype
   */
  uint16 ethertype;
  /* 
   *  Other data including: valid_entry(1bit), vlan (12bit), vlan_is_valid (1bit), tc (3bit), tc_is_valid(1bit)
   */
  uint32 vlan_tc_data;

} bcm_dpp_vlan_port_protocol_profile_info_t;

typedef struct bcm_dpp_vlan_port_protocol_entries_s {
   bcm_dpp_vlan_port_protocol_profile_info_t port_protocol_entry[DPP_PRTCL_NOF_ETHER_TYPE_IDS];
} bcm_dpp_vlan_port_protocol_entries_t;

void 
_bcm_dpp_vlan_egress_edit_profile_info_t_init(bcm_dpp_vlan_egress_edit_profile_info_t *info);

void 
_bcm_dpp_vlan_edit_profile_mapping_info_t_init(bcm_dpp_vlan_edit_profile_mapping_info_t *info);

int
_bcm_petra_vlan_edit_profile_info_hw_set(int unit,
                     int vlan_edit_profile,
                     bcm_dpp_vlan_edit_profile_mapping_info_t *mapping_info);

extern int
bcm_petra_vlan_detach(int unit);

void
_bcm_petra_vlan_edit_command_hw_get(int unit,
                                    int vlan_edit_profile,
                                    SOC_SAND_PP_ETHERNET_FRAME_VLAN_FORMAT vlan_format,
                                    int *ivec_id,
                                    uint8 *is_ivec_to_set,
                                    uint8 *is_vlan_format_valid);

extern int
_bcm_dpp_vlan_info_vlan_exist_get(int unit,
                                  bcm_vlan_t vlan,
                                  int *exists);

extern int
_bcm_dpp_vlan_info_vlan_exist_set(int unit,
                                  bcm_vlan_t vlan,
                                  int exists);

int 
_bcm_petra_vlan_translate_action_add(
    int unit, 
    bcm_gport_t port, 
    bcm_vlan_translate_key_t key_type, 
    bcm_vlan_t outer_vlan, 
    bcm_vlan_t inner_vlan, 
    bcm_vlan_action_set_t *action);

int
_bcm_petra_vlan_translate_match_tpid_value_to_index(int unit, int tpid_value, SOC_PPD_LLP_PARSE_TPID_VALUES* tpid_vals, int* tpid_index);

int
_bcm_petra_vlan_translate_match_tpid_index_to_value(int unit, int tpid_index, SOC_PPD_LLP_PARSE_TPID_VALUES* tpid_vals, uint16* tpid_value);

/* 
 * Advanced VLAN editing: action SW table Get/Set/Init functions
 */

/* Initialize BCM DPP VLAN editing action SW table structure.
   The structure is used in order to store a VLAN translation action in the SW */
void 
_bcm_dpp_vlan_translate_action_t_init(_bcm_dpp_vlan_translate_action_t *action);

/* Set a BCM DPP VLAN editing action structure that is stored in a SW actions table */
int
_bcm_dpp_vlan_edit_action_set(
    int unit,
    int action_id,
    uint32 is_ingress,
    _bcm_dpp_vlan_translate_action_t *action);

/* Get a BCM DPP VLAN editing action structure that is stored in a SW actions table */
int
_bcm_dpp_vlan_edit_action_get(
    int unit,
    int action_id,
    uint32 is_ingress,
    _bcm_dpp_vlan_translate_action_t *action);

/* Get tag format and profile from from action ID that is stored in  SW Egress action mapping table. */
int
_bcm_petra_vlan_edit_eg_command_id_find(
    int unit,
    uint32 action_id,
    int find_from_current,
    SOC_PPD_EG_VLAN_EDIT_COMMAND_KEY *command_key);

#endif    /* !_BCM_INT_DPP_VLAN_H */
