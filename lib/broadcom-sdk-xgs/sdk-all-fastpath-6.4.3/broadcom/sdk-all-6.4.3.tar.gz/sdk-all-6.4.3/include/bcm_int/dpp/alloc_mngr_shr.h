/*
 * $Id: alloc_mngr_shr.h,v 1.45 Broadcom SDK $
 * $Copyright: Copyright 2012 Broadcom Corporation.
 * This program is the proprietary software of Broadcom Corporation
 * and/or its licensors, and may only be used, duplicated, modified
 * or distributed pursuant to the terms and conditions of a separate,
 * written license agreement executed between you and Broadcom
 * (an "Authorized License").  Except as set forth in an Authorized
 * License, Broadcom grants no license (express or implied), right
 * to use, or waiver of any kind with respect to the Software, and
 * Broadcom expressly reserves all rights in and to the Software
 * and all intellectual property rights therein.  IF YOU HAVE
 * NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE
 * IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
 * ALL USE OF THE SOFTWARE.  
 *  
 * Except as expressly set forth in the Authorized License,
 *  
 * 1.     This program, including its structure, sequence and organization,
 * constitutes the valuable trade secrets of Broadcom, and you shall use
 * all reasonable efforts to protect the confidentiality thereof,
 * and to use this information only in connection with your use of
 * Broadcom integrated circuit products.
 *  
 * 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS
 * PROVIDED "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
 * REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY,
 * OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
 * DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
 * NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
 * ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
 * CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
 * OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
 * 
 * 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
 * BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL,
 * INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER
 * ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY
 * TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF
 * THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR USD 1.00,
 * WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
 * ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.$
 *
 * File:        alloc_mngr_shr.h
 * Purpose:     Resource allocation shared between alloc and wb.
 *
 */

#ifndef  INCLUDE_ALLOC_MNGR_SHR_H
#define  INCLUDE_ALLOC_MNGR_SHR_H

#include <soc/dpp/PPD/ppd_api_general.h>
#include <soc/dpp/drv.h>
#include <shared/shr_resmgr.h>
#include <shared/shr_template.h>
#include <soc/dpp/SAND/Utils/sand_occupation_bitmap.h>
#include <bcm_int/dpp/port.h>
#include <bcm_int/dpp/vlan.h>
#include <soc/dpp/PPD/ppd_api_eg_encap.h>
#include <soc/dpp/PPD/ppd_api_trap_mgmt.h>

/* Res managemr Defines and Structures. */
typedef enum _dpp_am_res_e {
    /****************************************/
    /************   TM POOLS   **************/
    /****************************************/
    dpp_am_res_mc_dynamic = 0,
    dpp_am_res_trap_single_instance,
    dpp_am_res_trap_user_define,
    dpp_am_res_trap_virtual,
    dpp_am_res_trap_reserved_mc,
    dpp_am_res_trap_prog,
    dpp_am_res_trap_egress,
    dpp_am_res_snoop_cmd,
    dpp_am_res_qos_egr_pcp_vlan,

    /****************************************/
    /************   PP POOLS   **************/
    /****************************************/
    dpp_am_res_vsi_vlan,
    dpp_am_res_vsi_mstp,
    dpp_am_res_lif_pwe,
    dpp_am_res_lif_ip_tnl,
    dpp_am_res_lif_dynamic,
    dpp_am_res_fec_global,
    dpp_am_res_failover_common_id,
    dpp_am_res_failover_ingress_id,
    dpp_am_res_failover_fec_id,
    dpp_am_res_failover_egress_id,
    dpp_am_res_eep_global,
    dpp_am_res_eep_ip_tnl, /* used for ip tunnels*/
    dpp_am_res_eep_mpls_tunnel, /* used for mpls/pwe tunnels*/
    dpp_am_res_eep_local,
    dpp_am_res_glbl_src_ip,
    dpp_am_res_glbl_ttl,
    dpp_am_res_glbl_tos,
    dpp_am_res_eg_out_ac,
    dpp_am_res_eg_out_rif,
    dpp_am_res_eg_data_erspan,
    dpp_am_res_ipv6_tunnel,
    dpp_am_res_eg_data_trill_invalid_entry,
    dpp_am_res_qos_ing_elsp,
    dpp_am_res_qos_ing_lif_cos,
    dpp_am_res_qos_ing_pcp_vlan,
    dpp_am_res_qos_ing_cos_opcode,
    dpp_am_res_qos_egr_remark_id,
    dpp_am_res_qos_egr_mpls_php_id,
    dpp_am_res_meter_a, /* must be directly before meter_b */
    dpp_am_res_meter_b, /* must be directly after meter_a */
    dpp_am_res_ether_policer,
#ifdef BCM_ARAD_SUPPORT
    dpp_am_res_ecmp_id,
#endif 
    dpp_am_res_qos_egr_l2_i_tag,
#ifdef BCM_88660
    dpp_am_res_qos_egr_dscp_exp_marking,
#endif /* BCM_88660 */
    dpp_am_res_rp_id, /* RPIDs for IPMC BIDIR*/
    dpp_am_res_oam_ma_index,
    dpp_am_res_oam_mep_id_short,
    dpp_am_res_oam_mep_id_long,
    dpp_am_res_oam_rmep_id,
    dpp_am_res_oam_trap_code_upmep_ftmh_header,
    dpp_am_res_pon_channel_profile,
    dpp_am_res_vlan_edit_action_ingress,
    dpp_am_res_vlan_edit_action_egress, 
    dpp_am_res_trill_virtual_nick_name
    ,dpp_am_res_count /* MUST BE LAST -- NOT A VALID ID */
} _dpp_am_res_t;

/* 
 * Pool structure for all pools other than cosq. 
 * for cosq see bcm_dpp_am_cosq_pool_info_t
 * A pool_id represents mapping between resource_id and core_id.
 */
typedef struct {
    int                 pool_id;        /* The pool on which the resource is allocated. */
    int                 res_id;         /* The resource using the pool. */
    int                 core_id;        /* The core using the pool.*/    
    shr_res_allocator_t res_type;       /* resource storage type */
    int                 start;          /* resource start */
    int                 count;          /* count of resources */
    int                 max_elements_per_allocation; /* required for wb storage */
} bcm_dpp_am_pool_info_t;


/* Template management Defines and Structures */
typedef enum _dpp_am_template_e {
    /****************************************/
    /************ TM TEMPLATES **************/
    /****************************************/
    dpp_am_template_egress_thresh = 0,
    dpp_am_template_mirror_action_profile,
    dpp_am_template_egress_interface_unicast_thresh,
    dpp_am_template_egress_interface_multicast_thresh,
    dpp_am_template_user_defined_traps,
    dpp_am_template_snoop_cmd,
    dpp_am_template_trap_reserved_mc,
    dpp_am_template_prog_trap,
    dpp_am_template_queue_rate_cls,
    dpp_am_template_system_red_dp_pr,
    dpp_am_template_vsq_rate_cls,
    dpp_am_template_queue_discount_cls,
    dpp_am_template_egress_port_discount_cls_type_raw,
    dpp_am_template_egress_port_discount_cls_type_cpu,
    dpp_am_template_egress_port_discount_cls_type_eth,
    dpp_am_template_egress_port_discount_cls_type_tm,
    dpp_am_template_cosq_port_hr_flow_control, /* e2e port hr flow control profile */
    dpp_am_template_cosq_sched_class,          /* scheduler (cl) class */
    dpp_am_template_fabric_tdm_link_ptr,       /* TDM Direct routing link pointer */
    dpp_am_template_ingress_flow_tc_mapping,    /* Ingress Flow TC Mapping Profiles */
    dpp_am_template_ingress_uc_tc_mapping,      /* Ingress UC TC Mapping Profiles */
    dpp_am_template_fc_generic_pfc_mapping,     /* Flow Control Generic PFC Profiles */
    dpp_am_template_cnm_queue_profile,
    dpp_am_template_tpid_profile,
    dpp_am_template_egress_queue_mapping,
    dpp_am_template_trap_egress,

    /****************************************/
    /************   PP POOLS   **************/
    /****************************************/
    dpp_am_template_vlan_edit_profile_mapping,    /* VLAN Edit Profile */
    dpp_am_template_vlan_edit_profile_mapping_eg, /* Egress VLAN Edit Profile */      
    dpp_am_template_vsi_egress_profile,
    dpp_am_template_vsi_ingress_profile,
    dpp_am_template_reserved_mc,
    dpp_am_template_tpid_class,
    dpp_am_template_mpls_push_profile,
    dpp_am_template_lif_term_profile,
    dpp_am_template_port_mact_sa_drop_profile,
    dpp_am_template_port_mact_da_unknown_profile,
    /* don't seperate between below 4 termplates */
    dpp_am_template_meter_profile_a_low, 
    dpp_am_template_meter_profile_a_high, 
    dpp_am_template_meter_profile_b_low, 
    dpp_am_template_meter_profile_b_high, 
    /* don't separate between above 4 templates */
    dpp_am_template_l2_event_handle,            /* from even-profile, to <event x self/learn/shadow> */
    dpp_am_template_l2_vsi_learn_profile,       /* from learn-profile to <limit, event-profile, aging-profile> */
    dpp_am_template_fid_aging_profile,          /* from aging-profile to <event x delete/aged out/refresh> */
    dpp_am_template_l2_flooding_profile,        /* flooding by <port_profile,lif_profile> */
    dpp_am_template_vlan_port_protocol_profile, /* port protocol mapping. <port,profile> ->10ethertype,tc,vlan */
    dpp_am_template_ip_tunnel_src_ip,
    dpp_am_template_ip_tunnel_ttl,
    dpp_am_template_ip_tunnel_tos,
    dpp_am_template_ttl_scope_index, 
    dpp_am_template_oam_icc_map,
    dpp_am_template_oam_sa_mac,
    dpp_am_template_oam_punt_event_hendling_profile,
    dpp_am_template_oam_mep_profile_non_accelerated,
    dpp_am_template_oam_mep_profile_accelerated,
    dpp_am_template_bfd_mep_profile_non_accelerated,
    dpp_am_template_bfd_mep_profile_accelerated,
    dpp_am_template_oam_tx_priority,
    dpp_am_template_bfd_ipv4_dip,
    dpp_am_template_mpls_pwe_push_profile,
    dpp_am_template_bfd_req_interval_pointer,
    dpp_am_template_bfd_tos_ttl_profile,
    dpp_am_template_bfd_src_ip_profile,
    dpp_am_template_bfd_tx_rate_profile,
    dpp_am_template_bfd_flags_profile,
    dpp_am_template_oam_lmm_nic_tables_profile,
    dpp_am_template_oam_lmm_oui_tables_profile,
    dpp_am_template_oam_eth1731_profile,
    dpp_am_template_oam_local_port_2_system_port,
    dpp_am_template_oam_oamp_pe_gen_mem,
    dpp_am_template_port_tpid_class_egress_acceptable_frame_type,
    dpp_am_template_ptp_port_profile,
    dpp_am_template_l3_vrrp,
    dpp_am_template_l3_rif_mac_termination_combination,
    dpp_am_template_eedb_roo_ll_format_eth_type_index
    ,dpp_am_template_count /* MUST BE LAST -- NOT A VALID ID */
} _dpp_am_template_t;


/* 
 * Template structure for templates other than those already supported by cosq
 * for warmboot.
 * A pool_id represents mapping between template id and core id.
 */
typedef struct {
    int                    pool_id;         /* Pool id of the pool. */
    int                    template_id;     /* Template id using the pool. */
    int                    core_id;         /* Core id using the pool. */
    shr_template_manage_t  manager;
    int                    start;
    int                    count;
    int                    max_entities; /* max referring entities */
    uint32                 global_max;  /* Max referring entinties on all templates. */
    size_t                 data_size;
    shr_template_manage_hash_compare_extras_t hashExtra;
} bcm_dpp_am_template_info_t;

int
_bcm_dpp_pp_resource_setup(int unit, int res_id, int core_id, int pool_id, bcm_dpp_am_pool_info_t *p_info);

int
_bcm_dpp_template_setup(int unit, int template_id, int core_id, int pool_id, bcm_dpp_am_template_info_t *t_info);

int
bcm_dpp_am_l2_vsi_vlan_alloc(int unit,
                             uint32 flags,
                             bcm_vlan_t *vsi);
int
bcm_dpp_am_l2_vpn_pwe_alloc(int unit,
                            uint32 lif_term_types,
                            uint32 flags,
                            int count,
                            SOC_PPD_LIF_ID *lif,
                            int *eep);
int
bcm_dpp_am_l3_lif_ip_tnl_alloc(int unit,
                               uint32 flags,
                               SOC_PPD_LIF_ID *lif);
int
bcm_dpp_am_l2_lif_mim_alloc(int unit);

int
bcm_dpp_am_mc_alloc(int unit,
                    uint32 flags, /* flags should be SHR_RES_ALLOC_WITH_ID; */
                    SOC_TMC_MULT_ID  *mc_id,
                    uint8 is_egress);


typedef enum {
  /* Standard FEC */
  _BCM_DPP_AM_FEC_ALLOC_USAGE_STANDARD,
  /* L3 ECMP - DEPRECATED - DO NOT USE - only used by bcm_l3_egress_multipath_* */
  _BCM_DPP_AM_FEC_ALLOC_USAGE_ECMP,
  /* Group-B FEC (for Hierarchical FEC) */
  _BCM_DPP_AM_FEC_ALLOC_USAGE_CASCADED
} _bcm_dpp_am_fec_alloc_usage;

int
bcm_dpp_am_fec_global_alloc(int unit,
                            uint32 flags,
                            _bcm_dpp_am_fec_alloc_usage usage,
                            int size,
                            int aligned,
                            int *elem); 
int
bcm_dpp_am_fec_alloc(int unit,
                     uint32 flags,
                     _bcm_dpp_am_fec_alloc_usage usage,
                     int size,/*non-zero for protection or ECMP*/
                     SOC_PPD_FEC_ID *fec_id);
int
bcm_dpp_am_failover_alloc(int unit,
                          uint32 flags,
                          int32 failover_type,
                          int32 nof_alloc_ids,
                          bcm_failover_t *failover_id);

#define _BCM_DPP_AM_L3_EEP_TYPE_DEFAULT (0) /* Link-layer */
#define _BCM_DPP_AM_L3_EEP_TYPE_ROO_LINKER_LAYER (1) /* ROO Linker-layer */

int
bcm_dpp_am_l3_eep_alloc(int unit,
                        uint32 types,
                        uint32 flags,
                        int *eep);

#define _BCM_DPP_AM_IP_TUNNEL_EEP_TYPE_DEFAULT (0) /* IP tunnel  */
#define _BCM_DPP_AM_IP_TUNNEL_EEP_TYPE_ROO     (1) /* ROO IP tunnel */
int
bcm_dpp_am_ip_tunnel_eep_alloc(int unit,
                               uint32 types, 
                               uint32 flags,
                               int *eep);

#define _BCM_DPP_AM_MPLS_EEP_TYPE_PWE                (0)
#define _BCM_DPP_AM_MPLS_EEP_TYPE_SIMPLE_MPLS_TUNNEL (1)
#define _BCM_DPP_AM_MPLS_EEP_TYPE_SECOND_MPLS_TUNNEL (2)
/* This type is for creating PWE with EGRESS_ONLY flag. The functionality is the same as _BCM_DPP_AM_MPLS_EEP_TYPE_SECOND_MPLS_TUNNEL */
#define _BCM_DPP_AM_MPLS_EEP_TYPE_PWE_EGRESS_ONLY    (3)
int
bcm_dpp_am_mpls_eep_alloc(int unit,
                          uint32 type,
                          uint32 flags,
                          int count,
                          int *eep);

int
bcm_dpp_am_ip_tunnel_glbl_src_ip_alloc(int unit,
                                       uint32 flags,
                                       int *idx);

int
bcm_dpp_am_ip_tunnel_glbl_ttl_alloc(int unit,
                                    uint32 flags,
                                    int *idx);
int
bcm_dpp_am_ip_tunnel_glbl_tos_alloc(int unit,
                                    uint32 flags,
                                    int *idx);

#define _BCM_DPP_AM_OUT_AC_TYPE_DEFAULT           (0)
#define _BCM_DPP_AM_OUT_AC_TYPE_PON_3_TAGS_DATA   (1)
#define _BCM_DPP_AM_OUT_AC_TYPE_PON_3_TAGS_OUT_AC (2)
#ifdef BCM_88660_A0
#define _BCM_DPP_AM_OUT_AC_TYPE_BIG_OUT_AC        (3)
#endif

int
bcm_dpp_am_out_ac_alloc(int unit,
                        uint32 types,
                        uint32 flags,
                        SOC_PPD_AC_ID *out_ac);

int
bcm_dpp_am_qos_ing_elsp_alloc(int unit,
                              uint32 flags,
                              int *qos_id);

int
bcm_dpp_am_qos_ing_lif_cos_alloc(int unit,
                                 uint32 flags,
                                 int *qos_id);


int
bcm_dpp_am_qos_ing_pcp_vlan_alloc(int unit,
                                  uint32 flags,
                                  int *qos_id);
int
bcm_dpp_am_qos_egr_remark_id_alloc(int unit,
                                   uint32 flags,
                                   int *qos_id);

int
bcm_dpp_am_qos_egr_mpls_php_id_alloc(int unit,
                                   uint32 flags,
                                   int *qos_id);

int
bcm_dpp_am_qos_egr_pcp_vlan_alloc(int unit,
                                  uint32 flags,
                                  int *qos_id);

int
bcm_dpp_am_qos_ing_cos_opcode_alloc(int unit,
                                    uint32 flags,
                                    int *qos_id);

int
bcm_dpp_am_qos_egr_l2_i_tag_alloc(int unit,
                                  uint32 flags,
                                  int *qos_id);

#ifdef BCM_88660
int
bcm_dpp_am_qos_egr_dscp_exp_marking_alloc(int unit,
                                  uint32 flags,
                                  int *qos_id);
#endif /* BCM_88660 */

int
bcm_dpp_am_meter_alloc(int unit,
                       uint32 flags,
                       int meter_group,
                       int nof_meters,
                       int *act_meter_group,
                       int *meter_id);
int
bcm_dpp_am_policer_alloc(int unit,
                         uint32 flags,
                         int size,
                         int *policer_id);
int
bcm_dpp_am_vrf_alloc(int unit,
                     uint32 flags,
                     int *vrf_id);

int
bcm_dpp_am_vlan_edit_action_id_alloc(int unit,
                                     uint32 flags,
                                     int *action_id);

int 
_bcm_dpp_am_trap_alloc(int unit,
                       int flags,
                       int trap_id,
                       int *elem);
int
_bcm_dpp_am_trap_single_instance_alloc(int unit,
                                       int flags,
                                       int *elem);
int
_bcm_dpp_am_trap_user_define_alloc(int unit,
                                   int flags,
                                   int *elem);
int
_bcm_dpp_am_trap_virtual_alloc(int unit,
                               int flags,
                               int *elem);

int
_bcm_dpp_am_trap_egress_alloc(int unit,
                              int flags,
                              int *elem);
int
_bcm_dpp_am_snoop_alloc(int unit,
                        int flags,
                        int snoop_cmnd,
                        int *elem);
int
_bcm_dpp_am_snoop_cmd_alloc(int unit,
                            int flags,
                            int *elem);

int 
_bcm_dpp_am_template_user_defined_trap_allocate(int unit,
                                                uint32 flags,
                                                int port,
                                                const bcm_dpp_user_defined_traps_t* data,
                                                int *is_allocated,
                                                int *user_defined_trap);

int 
_bcm_dpp_am_template_tpid_profile_allocate_group(int unit, 
                                                 uint32 flags, 
                                                 uint32 *data, 
                                                 int ref_count, 
                                                 int *is_allocated, 
                                                 int *template);


int 
_bcm_dpp_am_template_vlan_edit_profile_mapping_alloc(int unit, 
                                                     int flags, 
                                                     SOC_PPD_LIF_ID lif_id, 
                                                     bcm_dpp_vlan_edit_profile_mapping_info_t* mapping_profile, 
                                                     int *template,
                                                     int *is_allocated);

int 
_bcm_dpp_am_template_vlan_edit_profile_eg_mapping_allocate(int unit, 
                                                           uint32 flags, 
                                                           bcm_dpp_vlan_egress_edit_profile_info_t *mapping_profile, 
                                                           uint32 *template_id, 
                                                           int *is_allocated);

int _bcm_dpp_am_template_mpls_push_profile_alloc(int unit, 
                                                 int flags, 
                                                 int push_profile, 
                                                 SOC_PPD_EG_ENCAP_PUSH_PROFILE_INFO *push_profile_info, 
                                                 int *new_push_profile,
                                                 int *is_allocated);
int
_bcm_dpp_am_template_trap_egress_allocate(int unit,
                                          int flags,
                                          SOC_SAND_IN SOC_PPD_TRAP_EG_ACTION_PROFILE_INFO *data,
                                          int *template);

#endif /* INCLUDE_ALLOC_MNGR_SHR_H */
