/* 
 * $Id: utils.h,v 1.10 Broadcom SDK $
 * $Copyright: Copyright 2012 Broadcom Corporation.
 * This program is the proprietary software of Broadcom Corporation
 * and/or its licensors, and may only be used, duplicated, modified
 * or distributed pursuant to the terms and conditions of a separate,
 * written license agreement executed between you and Broadcom
 * (an "Authorized License").  Except as set forth in an Authorized
 * License, Broadcom grants no license (express or implied), right
 * to use, or waiver of any kind with respect to the Software, and
 * Broadcom expressly reserves all rights in and to the Software
 * and all intellectual property rights therein.  IF YOU HAVE
 * NO AUTHORIZED LICENSE, THEN YOU HAVE NO RIGHT TO USE THIS SOFTWARE
 * IN ANY WAY, AND SHOULD IMMEDIATELY NOTIFY BROADCOM AND DISCONTINUE
 * ALL USE OF THE SOFTWARE.  
 *  
 * Except as expressly set forth in the Authorized License,
 *  
 * 1.     This program, including its structure, sequence and organization,
 * constitutes the valuable trade secrets of Broadcom, and you shall use
 * all reasonable efforts to protect the confidentiality thereof,
 * and to use this information only in connection with your use of
 * Broadcom integrated circuit products.
 *  
 * 2.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS
 * PROVIDED "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
 * REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY,
 * OR OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
 * DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
 * NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
 * ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
 * CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
 * OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
 * 
 * 3.     TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
 * BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL,
 * INCIDENTAL, SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER
 * ARISING OUT OF OR IN ANY WAY RELATING TO YOUR USE OF OR INABILITY
 * TO USE THE SOFTWARE EVEN IF BROADCOM HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES; OR (ii) ANY AMOUNT IN EXCESS OF
 * THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF OR USD 1.00,
 * WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING
 * ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.$
 *
 * File:        bcm_sand.h
 * Purpose:     Conversion between BCM and SOC_SAND types, and common macros/function for
 *              handling Dune's code.
 */

#ifndef INCLUDE_DPP_UTILS_H
#define INCLUDE_DPP_UTILS_H

#include <bcm/error.h>
#include <bcm/types.h>
#include <bcm_int/dpp/cosq.h>
#include <bcm_int/dpp/multicast.h>
#include <soc/dpp/drv.h>
#include <soc/dpp/SAND/Utils/sand_pp_mac.h>
#include <soc/dpp/SAND/Management/sand_error_code.h>
#include <soc/dpp/TMC/tmc_api_general.h>
#include <soc/dpp/Petra/PB_PP/pb_pp_general.h>
#include <soc/dpp/TMC/tmc_api_ports.h>
#include <soc/dpp/PPD/ppd_api_trap_mgmt.h>
#include <soc/dpp/TMC/tmc_api_action_cmd.h>
#include <soc/dpp/SAND/Utils/sand_multi_set.h>

#define BCM_SAND_FAP_ID_TO_BCM_MODID(fap_id) (int)(fap_id)
#define BCM_SAND_FAP_PORT_ID_TO_BCM_PORT(fap_port_id) (int)(fap_port_id)

#define _BCM_DPP_CPU_DEST_PORT (0)

/* snoop comamnd reserved for no snooping */
/* snoop comamnd reserved for snoop all packet to CPU*/
#define _BCM_DPP_SNOOP_CMD_TO_CPU (1)

/* size of snooped packet (all packet) */
#define _BCM_DPP_SNOOP_SIZE (SOC_TMC_ACTION_CMD_SIZE_BYTES_ALL_PCKT)

/* Destination of snooped packet */
#define _BCM_DPP_SNOOP_DEST (_BCM_DPP_CPU_DEST_PORT)

#define FRAGMENT_SIZE                   (32)


/*
 * General Utility Macros
 */
#define BCM_DPP_UNIT_CHECK(unit) \
    do { \
    if (((unit) < 0) || ((unit) >= BCM_LOCAL_UNITS_MAX)) { return BCM_E_UNIT; }  \
    } while (0)
    

#define BCM_DPP_MIN_CHECK(arg, min) \
    do {   \
        if ((arg) < min) { return BCM_E_PARAM; } \
    } while (0)



/* Convert PBMP to one single port and verify that PBMP is with one member only */
#define DPP_PBMP_TO_SINGLE_PORT_GET(_pbmp, _local_port) \
    do { \
        int count; \
        BCM_PBMP_COUNT(_pbmp, count); \
        if (count != 1) { \
            return BCM_E_INTERNAL; \
        } \
        BCM_PBMP_ITER(_pbmp, _local_port) { \
           break; \
       } \
   } while (0)

/* Convert PBMP to one single port not matter which */
#define DPP_PBMP_SINGLE_PORT_GET(_pbmp, _local_port) \
    do { \
        int count; \
        BCM_PBMP_COUNT(_pbmp, count); \
        if (count == 0) { \
            return BCM_E_INTERNAL; \
        } \
        BCM_PBMP_ITER(_pbmp, _local_port) { \
           break; \
       } \
   } while (0)

/* If a pointer is not null, fill it with value */
#define DPP_IF_NOT_NULL_FILL(_p, _value) \
   do { \
   if ((_p) != NULL) {  \
       *(_p) = (_value);    \
   }    \
} while (0); 

/* Returns a pointers value if not null, otherwise returns 0 */
#define DPP_VALUE_IF_NOT_NULL(_p) \
    ((_p) ? *(_p) : 0)

#if defined(BCM_SBUSDMA_SUPPORT) || defined(BCM_88650_A0)
extern sbusdma_desc_handle_t _soc_port_tx_handles[FRAGMENT_SIZE][3];
#endif
extern volatile uint32 _soc_tx_pending[BCM_MAX_NUM_UNITS];



int
pbmp_from_ppd_port_bitmap(
    int unit, 
    bcm_pbmp_t *pbmp,
    uint32 *ports, 
    int ports_len);
    
int
pbmp_to_ppd_port_bitmap(
    int unit, 
    bcm_pbmp_t *pbmp,
    uint32 *ports, 
    int ports_len);

int
_bcm_petra_mac_to_sand_mac(
    bcm_mac_t bcm_mac,
    SOC_SAND_PP_MAC_ADDRESS *soc_ppd_mac);

int
_bcm_petra_mac_from_sand_mac(
    bcm_mac_t bcm_mac,
    SOC_SAND_PP_MAC_ADDRESS *soc_ppd_mac);

int
_bcm_petra_utils(
    bcm_mac_t bcm_mac,
    SOC_SAND_PP_MAC_ADDRESS *soc_ppd_mac);

/*
 *   Function
 *      _bcm_petra_pbmp_filter_by_core
 *   Purpose
 *      Returns only ports of the input core. 
 *
 *   Parameters
 *      (IN)  core_id      : required core
 *      (IN)  pbmp         : bcm_pbmp_t of local ports
 *      (OUT) core_pbmp    : returned pbmp: ports of the core
 *   Returns
 *       BCM_E_NONE - success
 *       BCM_E_*    - failure
 */

int
_bcm_pbmp_filter_by_core(
   int unit,
   int core_id,
   bcm_pbmp_t pbmp,
   bcm_pbmp_t *core_pbmp);

/*
 * resources definitions
 */
#define BCM_DPP_MAX_MC_ID(unit) (SOC_IS_PETRAB(unit) ? (SOC_TMC_MULT_NOF_MULTICAST_GROUPS_PETRA-1) :(SOC_TMC_MULT_NOF_MULTICAST_GROUPS_ARAD-1))
#define BCM_DPP_MAX_TRUNK_ID(unit) (SOC_TMC_PORT_LAGS_MAX)

/* needed to put these somewhere */
extern int bcm_petra_stat_stop(int unit);

/* Given a uint32 containing flags and a flag(s), sets another uint32 with a different flag(s)*/
#define DPP_TRANSLATE_FLAG(_src, _flag, _target, _target_flag)  \
        if ((_src) & (_flag)) {                                 \
            (_target) |= (_target_flag);                        \
        }

#define DPP_BMP_IS_SUBSET(_bmp, _subset)    \
    ((_bmp) == ((_bmp) | (_subset)))


#endif /* INCLUDE_DPP_UTILS_H */
